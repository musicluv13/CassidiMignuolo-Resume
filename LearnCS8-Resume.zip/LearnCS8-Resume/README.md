
# Welcome to Cassidi Mignuolo's Resume Website

This is a detailed resume for any jobs pertaining to marketing. 

Special thanks to the open source bootstrap libraries that made this website possible. 

![Website Preview](img/screenshot.png)
